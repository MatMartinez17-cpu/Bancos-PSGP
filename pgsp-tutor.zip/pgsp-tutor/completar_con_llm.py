#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
completar_con_llm.py — La vía ESCALABLE para "un montón de exámenes".

Idea: un LLM LEE el examen (imagen) y plantea cada problema como una llamada
a los solvers que ya existen (devuelve JSON con 'solver' + 'args'). Luego
SymPy CALCULA y deja la respuesta lista. El LLM hace la lectura y el
planteamiento; SymPy hace el cálculo exacto y verificable.

  imagen del examen → [LLM: plantear integrales] → solvers SymPy → JSON listo

Requiere:  pip install anthropic pymupdf
           y una API key:  export ANTHROPIC_API_KEY=...

Uso:
  python completar_con_llm.py "PC5 BMA02 24-2.pdf" --curso BMA02 --examen PC5 --periodo 24-2
"""
import argparse
import base64
import io
import json
import os
import re
import sys
from pathlib import Path

import fitz  # PyMuPDF
import sympy as sp

from pgsp import solvers, tutor

# ── Descripción de los solvers disponibles (se la damos al LLM) ───────────────
ESQUEMA_SOLVERS = """
Solvers disponibles y el formato EXACTO de 'args' (todo como cadenas de texto
que SymPy pueda parsear; usa 'x','t','theta','a','b' como variables/parámetros):

1) "area_curvas"  → área entre curvas por tramos
   args: {"segmentos": [[f_superior, f_inferior, a, b], ...]}
   ej:   {"segmentos": [["2*x","x**2",0,2]]}

2) "area_polar"  → área dentro de r_ext y fuera de r_int
   args: {"r_ext":"...", "r_int":"...", "a":"...", "b":"..."}
   ej:   {"r_ext":"6*cos(theta)","r_int":"2*(1+cos(theta))","a":"-pi/3","b":"pi/3"}

3) "longitud_parametrica"  → longitud de curva paramétrica
   args: {"x_t":"...", "y_t":"...", "a":"...", "b":"...", "n_arcos":1}

4) "volumen_discos"  → V=pi∫f(x)^2 dx (rotación alrededor del eje X)
   args: {"f":"...", "a":"...", "b":"..."}

5) "suma_integrales"  → GENÉRICO: suma de términos factor·∫integrando d(var)[a,b]
   Úsalo para casi todo (volumen por cascarones Ve−Vc, áreas paramétricas por
   la fórmula del shoelace, longitudes de arco explícitas, etc.).
   args: {"unidad":"u³", "terminos":[
            {"factor":"1","integrando":"...","var":"x","a":"...","b":"..."}, ...]}
"""

PROMPT_SISTEMA = (
    "Eres un profesor de Cálculo Integral. Te dan la imagen de un examen "
    "(en español). Para CADA problema, devuelve cómo resolverlo usando uno de "
    "los solvers dados, PLANTEANDO tú la integral correcta (encuentra "
    "intersecciones, asíntotas, parametrizaciones, etc.).\n\n" + ESQUEMA_SOLVERS +
    "\n\nDevuelve SOLO un JSON válido, sin texto adicional, con esta forma:\n"
    '{"problemas":[{"id":1,"enunciado":"...","solver":"...","args":{...}}, ...]}\n'
    "Si un problema no encaja en ningún solver, usa \"solver\":null y explica "
    "en \"nota\" por qué. No inventes resultados: solo PLANTEA; el cálculo lo "
    "hace SymPy después."
)


def render_paginas_b64(pdf_path: Path, dpi=170):
    doc = fitz.open(pdf_path)
    imgs = []
    for page in doc:
        pix = page.get_pixmap(dpi=dpi)
        imgs.append(base64.b64encode(pix.tobytes("png")).decode())
    doc.close()
    return imgs


def pedir_planteamiento_al_llm(imgs_b64):
    """Llama a la API de Anthropic. Devuelve la lista de problemas planteados."""
    import anthropic
    cliente = anthropic.Anthropic()  # toma ANTHROPIC_API_KEY del entorno
    contenido = [{"type": "image",
                  "source": {"type": "base64", "media_type": "image/png", "data": b}}
                 for b in imgs_b64]
    contenido.append({"type": "text", "text": "Plantea todos los problemas en JSON."})
    msg = cliente.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=4000,
        system=PROMPT_SISTEMA,
        messages=[{"role": "user", "content": contenido}],
    )
    texto = "".join(b.text for b in msg.content if b.type == "text")
    texto = re.sub(r"^```json|```$", "", texto.strip(), flags=re.MULTILINE).strip()
    return json.loads(texto)["problemas"]


def resolver_y_verificar(problemas):
    """Cada problema planteado por el LLM se RESUELVE con SymPy (cálculo exacto)."""
    for p in problemas:
        if not p.get("solver") or not p.get("args"):
            p["respuesta"] = None
            continue
        try:
            resp, _ = solvers.resolver(p["solver"], p["args"])
            p["respuesta_calculada"] = sp.sstr(resp) if resp is not None else None
        except Exception as e:
            p["respuesta_calculada"] = None
            p["error"] = str(e)
    return problemas


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--curso", required=True)
    ap.add_argument("--examen", required=True)
    ap.add_argument("--periodo", required=True)
    args = ap.parse_args(argv)

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("⚠️  Falta ANTHROPIC_API_KEY. Exporta tu clave antes de usar esto.")
        return

    pdf = Path(args.pdf)
    print(f"📷 Renderizando y enviando {pdf.name} al LLM para plantear...")
    problemas = pedir_planteamiento_al_llm(render_paginas_b64(pdf))
    print(f"🧠 El LLM planteó {len(problemas)} problema(s). Verificando con SymPy...")
    problemas = resolver_y_verificar(problemas)

    data = {"curso": args.curso, "nombre_curso": "", "examen": args.examen,
            "periodo": args.periodo, "fuente": f"recopilado ({pdf.name})",
            "problemas": problemas}
    destino = tutor.RAIZ_BANCOS / args.curso / \
        f"{args.examen}_{args.periodo}".lower().replace(" ", "") + ".json"
    Path(destino).parent.mkdir(parents=True, exist_ok=True)
    Path(destino).write_text(json.dumps(data, ensure_ascii=False, indent=2),
                             encoding="utf-8")
    ok = sum(1 for p in problemas if p.get("respuesta_calculada"))
    print(f"✅ Guardado {destino}  ({ok}/{len(problemas)} con respuesta calculada).")
    print("   Revisa los que quedaron en null: necesitan un solver nuevo o ajuste.")


if __name__ == "__main__":
    main(sys.argv[1:])
