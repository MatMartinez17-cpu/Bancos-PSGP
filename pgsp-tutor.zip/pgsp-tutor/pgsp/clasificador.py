# -*- coding: utf-8 -*-
"""pgsp/clasificador.py — La "puerta NLP": clasifica el tipo de problema."""
import re
import unicodedata

PATRONES = {
    "area_polar":      [r"\bpolar(es)?\b", r"\br\s*=\s*.*cos", r"\bcardioide\b"],
    "volumen_discos":  [r"\bvolumen\b", r"\bs[oó]lido\b", r"\brotar\b|\brevoluci[oó]n\b"],
    "longitud_parametrica": [r"\blongitud\b", r"\bper[ií]metro\b"],
    "area_curvas":     [r"\b[aá]rea\b", r"\bregi[oó]n\b", r"\bencerrad[ao]\b"],
}


def normalizar(texto: str) -> str:
    texto = unicodedata.normalize("NFD", texto)
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    return texto.lower().strip()


def clasificar(enunciado: str) -> str:
    """Devuelve el nombre del tipo de problema (= nombre del solver) o 'desconocido'."""
    msg = normalizar(enunciado)
    for tipo in ("area_polar", "volumen_discos", "longitud_parametrica", "area_curvas"):
        for patron in PATRONES[tipo]:
            if re.search(patron, msg):
                return tipo
    return "desconocido"
