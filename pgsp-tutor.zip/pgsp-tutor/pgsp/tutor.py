# -*- coding: utf-8 -*-
"""
pgsp/tutor.py — Orquestador. Carga los bancos de exámenes por curso
y resuelve sus problemas usando el registro de solvers.

Flujo:  banco JSON (datos)  →  clasificador (NLP)  →  solvers (SymPy)
        imagen escaneada     →  ocr (CV)            →  ...
"""
import json
from pathlib import Path
import sympy as sp

from . import solvers, clasificador, ocr

RAIZ_BANCOS = Path(__file__).resolve().parent.parent / "bancos"


def cursos_disponibles():
    """Lista los cursos que tienen banco de exámenes."""
    if not RAIZ_BANCOS.exists():
        return []
    return sorted(p.name for p in RAIZ_BANCOS.iterdir() if p.is_dir())


def examenes_de(curso: str):
    """Lista los exámenes (archivos JSON) de un curso."""
    carpeta = RAIZ_BANCOS / curso
    if not carpeta.exists():
        return []
    return sorted(p.stem for p in carpeta.glob("*.json"))


def cargar_examen(curso: str, examen: str) -> dict:
    ruta = RAIZ_BANCOS / curso / f"{examen}.json"
    if not ruta.exists():
        raise FileNotFoundError(f"No existe el banco: {ruta}")
    return json.loads(ruta.read_text(encoding="utf-8"))


def resolver_problema(prob: dict):
    """
    Resuelve un problema. Usa el solver indicado en el JSON; si no hay,
    intenta clasificar por NLP. Devuelve (respuesta, pasos).
    """
    args = prob.get("args")
    # Problema de demostración/análisis: sin solver → mostrar la nota
    if not prob.get("solver"):
        nota = prob.get("nota", "Requiere demostración o análisis, no un cálculo directo.")
        return None, [("Nota", nota)]
    if not args:
        return None, [("Faltan parámetros",
                       f"El problema usa '{prob['solver']}' pero no trae 'args'. "
                       f"(Aquí entraría el LLM como respaldo.)")]
    resp, pasos = solvers.resolver(prob["solver"], args)
    if prob.get("nota"):
        pasos = list(pasos) + [("Nota", prob["nota"])]
    return resp, pasos


def resolver_examen(curso: str, examen: str):
    """Resuelve todos los problemas de un examen. Devuelve lista de resultados."""
    data = cargar_examen(curso, examen)
    resultados = []
    for prob in data.get("problemas", []):
        resp, pasos = resolver_problema(prob)
        resultados.append({"id": prob.get("id"),
                           "enunciado": prob.get("enunciado", ""),
                           "respuesta": resp, "pasos": pasos})
    return data, resultados


def resolver_imagen(ruta_imagen: str):
    """CV→NLP→SymPy: lee una plancha escaneada y resuelve lo que reconozca."""
    enunciado = ocr.leer(ruta_imagen)
    tipo = clasificador.clasificar(enunciado)
    return enunciado, tipo


def formatear(resp, pasos) -> str:
    out = []
    for i, (titulo, contenido) in enumerate(pasos, 1):
        out.append(f"  {i}. {titulo}: {contenido}")
    if resp is not None:
        out.append(f"  ✅ Respuesta: {sp.sstr(resp)}")
    return "\n".join(out)
