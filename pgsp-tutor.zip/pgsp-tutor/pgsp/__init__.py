"""PGSP-Tutor: IA que lee y resuelve los problemas de exámenes por curso."""
__version__ = "0.1.0"
