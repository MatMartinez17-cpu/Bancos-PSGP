# -*- coding: utf-8 -*-
"""
pgsp/solvers.py — El "cerebro": resuelve con SymPy y genera los pasos.

Patrón clave para ESCALAR: un REGISTRO de solvers. Cada solver se registra
con un nombre; para agregar un tipo de problema nuevo, escribes una función
y le pones @registrar("nombre"). No tocas nada más.
"""
import re
import sympy as sp
from sympy.parsing.sympy_parser import (
    parse_expr, standard_transformations,
    implicit_multiplication_application, convert_xor)

# símbolos reales del tutor + mapa para que el parseo use NUESTROS símbolos
X, T, TH = sp.symbols("x t theta", real=True)
A = sp.symbols("a", positive=True)          # parámetro 'a' frecuente en exámenes
_LOCALS = {"x": X, "t": T, "theta": TH, "a": A,
           "sen": sp.sin, "tg": sp.tan, "pi": sp.pi, "e": sp.E,
           "exp": sp.exp, "ln": sp.log, "sqrt": sp.sqrt, "oo": sp.oo,
           "cbrt": sp.cbrt}
_VARS = {"x": X, "t": T, "theta": TH, "a": A}
_TRANSF = standard_transformations + (implicit_multiplication_application, convert_xor)


def S(expr):
    """Convierte texto a expresión SymPy admitiendo 'x^2' y '2x'."""
    if isinstance(expr, (int, float, sp.Expr)):
        return sp.sympify(expr, locals=_LOCALS)
    return parse_expr(str(expr), local_dict=_LOCALS, transformations=_TRANSF)


# ── REGISTRO DE SOLVERS ───────────────────────────────────────────────────
SOLVERS = {}

def registrar(nombre):
    def deco(fn):
        SOLVERS[nombre] = fn
        return fn
    return deco

def resolver(nombre_solver, args: dict):
    """Despacha al solver registrado. Devuelve (respuesta, pasos)."""
    if nombre_solver not in SOLVERS:
        return None, [("Solver no disponible",
                       f"No tengo un solver llamado '{nombre_solver}'. "
                       f"Disponibles: {', '.join(sorted(SOLVERS))}")]
    return SOLVERS[nombre_solver](args)


# ── SOLVERS CONCRETOS (validados contra el PC5 BMA02 2025-2) ───────────────

@registrar("area_curvas")
def _area_curvas(args):
    """args: {'segmentos': [[f_sup, f_inf, a, b], ...]}"""
    pasos = [("Identificar el tipo",
              "ÁREA entre curvas: ∫ (curva superior − inferior) por tramo.")]
    total = sp.Integer(0)
    for i, (sup, inf, a, b) in enumerate(args["segmentos"], 1):
        sup, inf, a, b = S(sup), S(inf), S(a), S(b)
        integrando = sp.simplify(sup - inf)
        primitiva = sp.simplify(sp.integrate(integrando, X))
        valor = sp.integrate(integrando, (X, a, b))
        total += valor
        pasos.append((f"Tramo {i}",
                      f"∫[{a},{b}] ({sp.sstr(sup)} − {sp.sstr(inf)}) dx = {sp.sstr(sp.simplify(valor))}"))
    resp = sp.simplify(total)
    pasos.append(("Respuesta", f"A = {sp.sstr(resp)} u²"))
    return resp, pasos


@registrar("area_polar")
def _area_polar(args):
    """args: {'r_ext':..., 'r_int':..., 'a':..., 'b':...}"""
    r_ext, r_int = S(args["r_ext"]), S(args["r_int"])
    a, b = S(args["a"]), S(args["b"])
    integrando = sp.simplify(r_ext**2 - r_int**2)
    resp = sp.simplify(sp.integrate(integrando, (TH, a, b)) / 2)
    pasos = [("Identificar el tipo", "Área POLAR: A = (1/2)∫ (r_ext² − r_int²) dθ."),
             ("Plantear", f"(1/2)∫[{sp.sstr(a)},{sp.sstr(b)}] ({sp.sstr(integrando)}) dθ"),
             ("Respuesta", f"A = {sp.sstr(resp)} u²")]
    return resp, pasos


def _raiz_trig(radicando):
    """√(A∓A·cos w) = √(2A)·|sen o cos (w/2)|."""
    A = sp.Wild("A", exclude=[T]); w = sp.Wild("w")
    m = radicando.match(A - A * sp.cos(w))
    if m and m[A] != 0:
        return sp.sqrt(2 * m[A]) * sp.sin(m[w] / 2)
    m = radicando.match(A + A * sp.cos(w))
    if m and m[A] != 0:
        return sp.sqrt(2 * m[A]) * sp.cos(m[w] / 2)
    return None


@registrar("longitud_parametrica")
def _longitud(args):
    """args: {'x_t':..., 'y_t':..., 'a':..., 'b':..., 'n_arcos':1}"""
    x_t, y_t = S(args["x_t"]), S(args["y_t"])
    a, b = S(args["a"]), S(args["b"])
    n = int(args.get("n_arcos", 1))
    xp, yp = sp.diff(x_t, T), sp.diff(y_t, T)
    radicando = sp.simplify(xp**2 + yp**2)
    pasos = [("Identificar el tipo", "LONGITUD paramétrica: L = ∫ √(x'² + y'²) dt."),
             ("Derivar", f"x'={sp.sstr(sp.simplify(xp))}, y'={sp.sstr(sp.simplify(yp))}"),
             ("Integrando", f"x'²+y'² = {sp.sstr(radicando)}")]
    raiz = _raiz_trig(radicando)
    integrando = raiz if raiz is not None else sp.sqrt(radicando)
    if raiz is not None:
        pasos.append(("Identidad ángulo mitad", f"√(x'²+y'²) = {sp.sstr(sp.Abs(raiz))}"))
    if n > 1:
        sub_b = sp.nsimplify((b - a) / n + a)
        L = n * sp.integrate(integrando, (T, a, sub_b))
        pasos.append(("Simetría", f"{n} arcos: integramos uno en [{sp.sstr(a)},{sp.sstr(sub_b)}]×{n}."))
    else:
        L = sp.integrate(integrando, (T, a, b))
    resp = sp.simplify(L)
    pasos.append(("Respuesta", f"L = {sp.sstr(resp)} u"))
    return resp, pasos


@registrar("volumen_discos")
def _volumen_discos(args):
    """args: {'f':..., 'a':..., 'b':...} — rota y=f(x) alrededor del eje X."""
    f, a, b = S(args["f"]), S(args["a"]), S(args["b"])
    resp = sp.simplify(sp.pi * sp.integrate(f**2, (X, a, b)))
    pasos = [("Identificar el tipo", "VOLUMEN por discos: V = π∫ f(x)² dx."),
             ("Plantear", f"π ∫[{sp.sstr(a)},{sp.sstr(b)}] ({sp.sstr(f)})² dx"),
             ("Respuesta", f"V = {sp.sstr(resp)} u³")]
    return resp, pasos


@registrar("suma_integrales")
def _suma_integrales(args):
    """
    Solver GENÉRICO: suma de términos  factor · ∫ integrando d(var) [a,b].
    Cubre casi todo: área por tramos, volumen Ve−Vc, longitud de arco, etc.
    args: {'terminos': [{'factor':1,'integrando':...,'var':'x','a':...,'b':...}, ...],
           'unidad': 'u²'}
    """
    pasos = [("Identificar el tipo",
              "Cálculo por integrales definidas (área/volumen/longitud).")]
    total = sp.Integer(0)
    for i, term in enumerate(args["terminos"], 1):
        var = _VARS.get(term.get("var", "x"), X)
        factor = S(term.get("factor", 1))
        integrando = S(term["integrando"])
        a, b = S(term["a"]), S(term["b"])
        valor = factor * sp.integrate(integrando, (var, a, b))
        total += valor
        signo = "" if i == 1 else " (se suma) "
        pasos.append((f"Término {i}{signo}",
                      f"{sp.sstr(factor)} · ∫[{sp.sstr(a)},{sp.sstr(b)}] "
                      f"({sp.sstr(integrando)}) d{var} = {sp.sstr(sp.simplify(valor))}"))
    resp = sp.simplify(total)
    pasos.append(("Respuesta", f"{sp.sstr(resp)} {args.get('unidad','')}".strip()))
    return resp, pasos


# ════════════════════════════════════════════════════════════════════════════
#  Cálculo Diferencial (BMA01): límite, derivada, diferenciales, optimización
# ════════════════════════════════════════════════════════════════════════════

@registrar("limite")
def _limite(args):
    """args: {'f':..., 'punto':..., 'var':'x', 'lado':'+'/'-' (opcional)}"""
    v = _VARS.get(args.get("var", "x"), X)
    f = S(args["f"]); pt = S(args["punto"]); lado = args.get("lado")
    L = sp.limit(f, v, pt, lado) if lado in ("+", "-") else sp.limit(f, v, pt)
    resp = sp.simplify(L)
    return resp, [("Tipo", f"LÍMITE de {sp.sstr(f)} cuando {args.get('var','x')}→{sp.sstr(pt)}."),
                  ("Respuesta", f"lim = {sp.sstr(resp)}")]


@registrar("derivada")
def _derivada(args):
    """args: {'f':..., 'var':'x', 'orden':1, 'punto':None}"""
    v = _VARS.get(args.get("var", "x"), X)
    f = S(args["f"]); n = int(args.get("orden", 1))
    d = sp.diff(f, v, n); resp = sp.simplify(d)
    pasos = [("Tipo", f"DERIVADA de orden {n} de {sp.sstr(f)}."),
             ("Derivar", f"f{'´'*n} = {sp.sstr(resp)}")]
    if args.get("punto") is not None:
        pt = S(args["punto"]); resp = sp.simplify(d.subs(v, pt))
        pasos.append(("Evaluar", f"en {sp.sstr(pt)}: {sp.sstr(resp)}"))
    return resp, pasos


@registrar("aproximacion_lineal")
def _aprox(args):
    """args: {'f':..., 'a':..., 'dx':..., 'var':'x'}  (diferenciales)"""
    v = _VARS.get(args.get("var", "x"), X)
    f = S(args["f"]); a = S(args["a"]); dx = S(args["dx"])
    fa = sp.simplify(f.subs(v, a)); fpa = sp.simplify(sp.diff(f, v).subs(v, a))
    resp = sp.simplify(fa + fpa * dx)
    return resp, [("Tipo", "APROXIMACIÓN LINEAL: f(a+dx) ≈ f(a)+f'(a)·dx."),
                  ("Datos", f"f(a)={sp.sstr(fa)}, f'(a)={sp.sstr(fpa)}, dx={sp.sstr(dx)}"),
                  ("Respuesta", f"≈ {sp.sstr(resp)} ≈ {float(resp):.5f}")]


@registrar("optimizacion")
def _optim(args):
    """args: {'f':..., 'a':..., 'b':..., 'var':'x'}"""
    v = _VARS.get(args.get("var", "x"), X)
    f = S(args["f"]); a = S(args["a"]); b = S(args["b"])
    cp = [c for c in sp.solve(sp.diff(f, v), v)
          if c.is_real and c.is_number and a <= c <= b]
    vals = [(p, sp.simplify(f.subs(v, p))) for p in cp + [a, b]]
    pmax = max(vals, key=lambda t: t[1]); pmin = min(vals, key=lambda t: t[1])
    return pmax[1], [("Tipo", f"OPTIMIZACIÓN de {sp.sstr(f)} en [{sp.sstr(a)},{sp.sstr(b)}]."),
                     ("Críticos+bordes", ", ".join(f"{sp.sstr(p)}→{sp.sstr(val)}" for p, val in vals)),
                     ("Máximo", f"{sp.sstr(pmax[1])} en {sp.sstr(pmax[0])}"),
                     ("Mínimo", f"{sp.sstr(pmin[1])} en {sp.sstr(pmin[0])}")]


# ════════════════════════════════════════════════════════════════════════════
#  Álgebra Lineal (BMA03): determinante, inversa, sistema, autovalores, expr
# ════════════════════════════════════════════════════════════════════════════

def _matriz(rows):
    return sp.Matrix([[S(e) for e in fila] for fila in rows])


@registrar("determinante")
def _det(args):
    M = _matriz(args["A"]); d = sp.simplify(M.det())
    return d, [("Tipo", f"DETERMINANTE {M.rows}×{M.cols}."), ("Respuesta", f"det = {sp.sstr(d)}")]


@registrar("matriz_inversa")
def _inv(args):
    M = _matriz(args["A"]); inv = sp.simplify(M.inv())
    pasos = [("Tipo", "MATRIZ INVERSA A⁻¹."),
             ("det A", f"{sp.sstr(M.det())} (≠0 ⇒ invertible)"), ("A⁻¹", sp.sstr(inv))]
    if args.get("entrada"):
        i, j = args["entrada"]; val = sp.simplify(inv[i - 1, j - 1])
        pasos.append(("Entrada", f"(A⁻¹)[{i},{j}] = {sp.sstr(val)}"))
        return val, pasos
    return inv, pasos


@registrar("sistema_lineal")
def _sistema(args):
    M = _matriz(args["A"]); b = sp.Matrix([S(x) for x in args["b"]])
    pasos = [("Tipo", "SISTEMA LINEAL A·x = b.")]
    if M.rows == M.cols:
        pasos.append(("det(A)", f"{sp.sstr(sp.factor(M.det()))} (≠0 ⇒ solución única)"))
    sol = sp.linsolve((M, b))
    pasos.append(("Solución", sp.sstr(sol)))
    return sol, pasos


@registrar("autovalores")
def _autoval(args):
    M = _matriz(args["A"]); ev = M.eigenvals()
    return (sp.sstr(ev),
            [("Tipo", "AUTOVALORES, det(A−λI)=0."),
             ("Autovalores", ", ".join(f"λ={sp.sstr(k)} (mult {v})" for k, v in ev.items()))])


@registrar("matriz_expr")
def _mexpr(args):
    """args: {'matrices':{'A':[[...]]}, 'expr':'(eye(4)+A.inv())/3', 'entrada':[i,j]}"""
    ns = {k: _matriz(v) for k, v in args["matrices"].items()}
    ns.update({"eye": sp.eye, "zeros": sp.zeros, "ones": sp.ones, "Rational": sp.Rational})
    M = eval(args["expr"], {"__builtins__": {}}, ns)
    pasos = [("Tipo", "OPERACIÓN MATRICIAL."), ("Expresión", str(args["expr"]))]
    if args.get("entrada") and hasattr(M, "shape"):
        i, j = args["entrada"]; val = sp.simplify(M[i - 1, j - 1])
        pasos.append(("Entrada", f"resultado[{i},{j}] = {sp.sstr(val)}"))
        return val, pasos
    M = sp.simplify(M)
    pasos.append(("Resultado", sp.sstr(M)))
    return M, pasos
