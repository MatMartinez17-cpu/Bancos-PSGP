# -*- coding: utf-8 -*-
"""pgsp/ocr.py — La "puerta CV": lee el enunciado de una plancha escaneada.

Nota honesta: Tesseract lee bien el texto narrativo pero estropea las
fórmulas. Para notación matemática seria se recomienda un OCR de LaTeX
(p. ej. pix2tex). Aquí limpiamos los errores más comunes del OCR.
"""
try:
    from PIL import Image
    import pytesseract
    DISPONIBLE = True
except ImportError:
    DISPONIBLE = False

_FIX = {'"': '^', '“': '^', '”': '^', '’': '^', '`': '^',
        '×': '*', '·': '*', '−': '-', '–': '-'}


def limpiar(texto: str) -> str:
    for malo, bueno in _FIX.items():
        texto = texto.replace(malo, bueno)
    return texto


def leer(ruta_imagen, idioma="spa") -> str:
    if not DISPONIBLE:
        return "[Instala pillow y pytesseract para leer imágenes]"
    img = Image.open(ruta_imagen).convert("L")
    img = img.resize((img.width * 2, img.height * 2))
    txt = pytesseract.image_to_string(img, lang=idioma, config="--psm 6")
    return limpiar(txt.strip())
