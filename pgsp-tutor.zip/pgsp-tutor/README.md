# PGSP-Tutor 🧮

IA que **lee y resuelve los problemas de exámenes**, organizada **por curso**.
Cada problema se resuelve con cómputo simbólico (SymPy), de forma exacta y
verificable, y se muestra el procedimiento paso a paso.

## La idea en una frase

> **Los datos (exámenes) y el código (los que resuelven) van por separado, y
> ambos se organizan por curso.** Para añadir exámenes solo agregas archivos
> de datos; para añadir tipos de problema solo registras un solver nuevo.

Tres capas:

1. **CV (OCR)** — lee el enunciado de una plancha escaneada → `pgsp/ocr.py`
2. **NLP** — clasifica el tipo de problema → `pgsp/clasificador.py`
3. **SymPy** — resuelve y genera los pasos (el "cerebro") → `pgsp/solvers.py`

## Estructura

```
pgsp-tutor/
├── resolver.py            ← CLI principal
├── requirements.txt
├── bancos/                ← LOS DATOS: exámenes en JSON, por curso
│   └── BMA02/             (Cálculo Integral)
│       └── pc5_2025-2.json
└── pgsp/                  ← EL CÓDIGO
    ├── solvers.py         (registro de solvers SymPy)
    ├── clasificador.py    (NLP)
    ├── ocr.py             (CV)
    └── tutor.py           (orquestador)
```

## Uso

```bash
pip install -r requirements.txt

python resolver.py                      # lista cursos y exámenes
python resolver.py BMA02                # exámenes del curso
python resolver.py BMA02 pc5_2025-2     # resuelve el examen, paso a paso
python resolver.py --imagen plancha.png # lee una plancha escaneada (OCR)
```

## De PDF a JSON: el flujo de trabajo real

Los exámenes vienen en PDF. `ingestar.py` automatiza lo tedioso y deja para
ti (o un LLM) solo el paso que requiere criterio:

```bash
# un PDF:
python ingestar.py "PC4 BMA02 24-2.pdf" --curso BMA02 --examen PC4 --periodo 24-2

# toda una carpeta descargada del Drive (infiere curso/examen/periodo del nombre):
python ingestar.py --carpeta ./descargas_drive
```

Esto genera un **borrador** en `bancos/<CURSO>/<examen>.json` con:
- el **enunciado** de cada problema (separado por "Pregunta N"),
- el **tipo sugerido** por el NLP,
- y `"solver": null`, `"args": {}`, `"_revisar": true`.

Luego tú **completas `solver` y `args`** (las funciones y límites exactos) y
quitas `_revisar`. Por qué ese paso es manual: el texto del PDF aplana las
fórmulas (`x²/2` sale como `x2 2`), así que extraer los parámetros exactos de
forma automática no es fiable. Un humano —o un LLM con verificación de
SymPy— lo completa en segundos.

Pipeline completo:

```
PDF → ingestar.py → borrador JSON → (completas args) → resolver.py → ✅ con pasos
```

## Cómo agregar un examen nuevo (sin tocar código)

Crea un JSON en `bancos/<CURSO>/<examen>.json`:

```json
{
  "curso": "BMA02",
  "nombre_curso": "Cálculo Integral",
  "examen": "PC4",
  "periodo": "2024-2",
  "problemas": [
    {
      "id": 1,
      "enunciado": "Calcule el área entre y=x^2 y y=2x",
      "solver": "area_curvas",
      "args": { "segmentos": [["2*x", "x**2", 0, 2]] },
      "respuesta_esperada": "4/3"
    }
  ]
}
```

El campo `respuesta_esperada` es opcional: si lo pones, el sistema **se
autoverifica** (compara su resultado con el que esperabas).

## Cómo agregar un TIPO de problema nuevo

En `pgsp/solvers.py`, escribe una función y regístrala:

```python
@registrar("mi_tipo")
def _mi_solver(args):
    ...
    return respuesta, pasos
```

Listo: ya puedes usar `"solver": "mi_tipo"` en cualquier examen.

## Solvers disponibles hoy

**Cálculo Integral:** `area_curvas`, `area_polar`, `longitud_parametrica`,
`volumen_discos`, `suma_integrales` (genérico).
**Cálculo Diferencial:** `limite`, `derivada`, `aproximacion_lineal`, `optimizacion`.
**Álgebra Lineal:** `determinante`, `matriz_inversa`, `sistema_lineal`,
`autovalores`, `matriz_expr`.

## Exámenes en el banco (verificados con SymPy)

| Curso | Examen | Problemas | Verificación |
|-------|--------|-----------|--------------|
| BMA02 Cálculo Integral | PC5 25-2 | 7 | 7/7 (clave de D. Villanueva) |
| BMA02 Cálculo Integral | PC5 26-1 | 2 | calculado |
| BMA01 Cálculo Diferencial | PC1 26-1 | 3 | límites verificados |
| BMA01 Cálculo Diferencial | PC3 25-2 | 1 | verificado |
| BMA03 Álgebra Lineal | PC2 26-1 | 6 | matrices verificadas |

Los problemas de demostración (ε-δ, axiomas, subespacios) quedan con una
`nota` honesta: no son cálculos, son pruebas — candidatos a la rama LLM.

## Límites honestos (importante para crecer)

- Los solvers SymPy son **exactos pero acotados**: solo resuelven los tipos que
  programaste. Ideales para cursos de matemática (cálculo, álgebra).
- Para resolver **cualquier** problema de **cualquier** curso, la vía completa
  es un **LLM** como motor general, **verificando** su respuesta con SymPy
  cuando el problema sea simbólico. Esa es la extensión natural (rama futura).
- El OCR de Tesseract lee bien el texto, pero **estropea las fórmulas**. Para
  notación matemática seria usa un OCR de LaTeX (pix2tex).

## ⚠️ Sobre publicar exámenes recopilados

Los escaneos de exámenes ajenos pueden tener derechos de autor de sus docentes.
El `.gitignore` **excluye los PDF/imágenes**: versiona solo los **JSON que tú
creas** (los enunciados estructurados). Si el repositorio será público,
mantén los escaneos fuera; si los necesitas versionados, usa un repo **privado**.
```
