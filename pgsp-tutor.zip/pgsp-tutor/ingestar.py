#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ingestar.py — Convierte PDFs de exámenes en BORRADORES de JSON para el tutor.

Qué AUTOMATIZA (lo tedioso):
  • Leer el PDF (texto nativo; si es escaneado, OCR por página).
  • Partirlo en problemas (por "Pregunta N" / "Problema N").
  • Crear el JSON con el enunciado de cada problema y la estructura correcta,
    dejando 'solver' y 'args' en blanco con la marca "_revisar": true.

Qué NO automatiza (y por qué):
  • Rellenar 'args' (las funciones y límites exactos). El OCR aplana las
    fórmulas y extraer los parámetros exactos de texto libre no es fiable.
    Ese paso lo completas tú (o un LLM) y luego el tutor verifica con SymPy.

Uso:
  python ingestar.py examen.pdf --curso BMA02 --examen PC5 --periodo 25-2
  python ingestar.py --carpeta ./descargas_drive      (procesa todos los PDFs)
"""
import argparse
import io
import json
import re
import sys
import unicodedata
from pathlib import Path

import fitz  # PyMuPDF

try:
    from PIL import Image
    import pytesseract
    _OCR = True
except ImportError:
    _OCR = False

RAIZ_BANCOS = Path(__file__).resolve().parent / "bancos"

# patrones para clasificar (reusa la idea del NLP del tutor)
_PATRONES_TIPO = {
    "area_polar":            [r"polar", r"r\s*=\s*.*cos", r"cardioide"],
    "volumen_discos":        [r"volumen", r"solido", r"rotar", r"revolucion"],
    "longitud_parametrica":  [r"longitud", r"perimetro"],
    "area_curvas":           [r"area", r"region", r"encerrad"],
}


def _norm(t: str) -> str:
    t = unicodedata.normalize("NFD", t)
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return t.lower()


def clasificar(enunciado: str) -> str:
    msg = _norm(enunciado)
    for tipo, pats in _PATRONES_TIPO.items():
        if any(re.search(p, msg) for p in pats):
            return tipo
    return "desconocido"


def extraer_texto(pdf_path: Path) -> str:
    """Texto nativo del PDF; si una página viene vacía (escaneada), usa OCR."""
    doc = fitz.open(pdf_path)
    paginas = []
    for page in doc:
        t = page.get_text().strip()
        if len(t) < 25 and _OCR:           # probablemente escaneada
            pix = page.get_pixmap(dpi=200)
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            t = pytesseract.image_to_string(img, lang="spa").strip()
        paginas.append(t)
    doc.close()
    return "\n".join(paginas)


def dividir_en_problemas(texto: str):
    """Parte el texto por 'Pregunta N' o 'Problema N'. Devuelve [(num, cuerpo)]."""
    partes = re.split(r"(?im)\b(?:pregunta|problema|ejercicio)\s+(\d+)\b", texto)
    problemas = []
    for i in range(1, len(partes), 2):
        num = int(partes[i])
        cuerpo = re.sub(r"\s+", " ", partes[i + 1]).strip()
        problemas.append((num, cuerpo))
    return problemas


def _primera_frase(cuerpo: str, limite: int = 280) -> str:
    """Toma el enunciado (hasta el primer punto largo o el límite)."""
    corte = cuerpo[:limite]
    m = re.search(r"\.\s", corte)
    return (corte[:m.start() + 1] if m else corte).strip()


def construir_borrador(pdf_path: Path, curso, examen, periodo) -> dict:
    texto = extraer_texto(pdf_path)
    problemas = dividir_en_problemas(texto)
    data = {
        "curso": curso,
        "nombre_curso": "",                 # complétalo tú
        "examen": examen,
        "periodo": periodo,
        "fuente": f"recopilado ({pdf_path.name})",
        "problemas": [],
    }
    if not problemas:                       # no detectó "Pregunta N": un solo bloque
        problemas = [(1, re.sub(r"\s+", " ", texto).strip())]
    for num, cuerpo in problemas:
        enun = _primera_frase(cuerpo)
        data["problemas"].append({
            "id": num,
            "enunciado": enun,
            "tipo_sugerido": clasificar(enun),
            "solver": None,                 # ← COMPLETAR
            "args": {},                     # ← COMPLETAR
            "_revisar": True,
        })
    return data


# ── inferir curso / examen / periodo desde el nombre del archivo ──────────────
_RE_CURSO   = re.compile(r"\b([A-Z]{2,4}\d{2,3})\b")
_RE_EXAMEN  = re.compile(r"(?i)\b(PC\s*\d|parcial|final|susti|entrada)\b")
_RE_PERIODO = re.compile(r"\b(\d{2})\s*[-_]\s*([123])\b")


def inferir_metadatos(nombre: str):
    curso = (_RE_CURSO.search(nombre) or [None, "CURSO"])[1] if _RE_CURSO.search(nombre) \
            else "CURSO"
    me = _RE_EXAMEN.search(nombre)
    examen = re.sub(r"\s+", "", me.group(1)).upper() if me else "EXAMEN"
    mp = _RE_PERIODO.search(nombre)
    periodo = f"{mp.group(1)}-{mp.group(2)}" if mp else "PERIODO"
    return curso, examen, periodo


def guardar(data: dict):
    curso = data["curso"]
    nombre = f"{data['examen']}_{data['periodo']}".lower().replace(" ", "")
    carpeta = RAIZ_BANCOS / curso
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = carpeta / f"{nombre}.json"
    destino.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    n = len(data["problemas"])
    print(f"   📝 {destino}  ({n} problema(s), marcados para revisar)")
    return destino


def main(argv):
    ap = argparse.ArgumentParser(description="Ingestor de PDFs → JSON borrador")
    ap.add_argument("pdf", nargs="?", help="ruta a un PDF")
    ap.add_argument("--carpeta", help="procesa todos los PDFs de una carpeta (recursivo)")
    ap.add_argument("--curso"); ap.add_argument("--examen"); ap.add_argument("--periodo")
    args = ap.parse_args(argv)

    if args.carpeta:
        pdfs = sorted(Path(args.carpeta).rglob("*.pdf"))
        print(f"📂 {len(pdfs)} PDF(s) encontrados en {args.carpeta}")
        for p in pdfs:
            curso, examen, periodo = inferir_metadatos(p.name)
            print(f"\n▶ {p.name}  →  curso={curso}, examen={examen}, periodo={periodo}")
            guardar(construir_borrador(p, curso, examen, periodo))
        print("\n✅ Listo. Revisa los JSON y completa 'solver' y 'args'.")
        return

    if not args.pdf:
        ap.print_help(); return
    pdf = Path(args.pdf)
    curso = args.curso or inferir_metadatos(pdf.name)[0]
    examen = args.examen or inferir_metadatos(pdf.name)[1]
    periodo = args.periodo or inferir_metadatos(pdf.name)[2]
    print(f"▶ {pdf.name}  →  curso={curso}, examen={examen}, periodo={periodo}")
    guardar(construir_borrador(pdf, curso, examen, periodo))
    print("\n✅ Borrador creado. Completa 'solver' y 'args', luego:")
    print(f"   python resolver.py {curso} {examen.lower()}_{periodo}")


if __name__ == "__main__":
    main(sys.argv[1:])
