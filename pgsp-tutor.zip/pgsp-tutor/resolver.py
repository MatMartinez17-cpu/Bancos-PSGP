#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
resolver.py — Línea de comandos del tutor.

Uso:
  python resolver.py                       → lista cursos y exámenes
  python resolver.py BMA02                 → lista exámenes del curso
  python resolver.py BMA02 pc5_2025-2      → resuelve ese examen, paso a paso
  python resolver.py --imagen plancha.png  → lee una plancha escaneada (OCR)
"""
import sys
import sympy as sp
from pgsp import tutor, solvers


def main(argv):
    if not argv:
        print("📚 Cursos con banco de exámenes:")
        for c in tutor.cursos_disponibles():
            print(f"   • {c}: {tutor.examenes_de(c)}")
        print("\nUso: python resolver.py <CURSO> <EXAMEN>")
        return

    if argv[0] == "--imagen":
        enunciado, tipo = tutor.resolver_imagen(argv[1])
        print(f"📷 OCR leyó: {enunciado!r}")
        print(f"🧠 NLP clasifica como: {tipo}")
        return

    curso = argv[0]
    if len(argv) == 1:
        print(f"Exámenes de {curso}: {tutor.examenes_de(curso)}")
        return

    examen = argv[1]
    data, resultados = tutor.resolver_examen(curso, examen)
    print("═" * 68)
    print(f"  {data['nombre_curso']} ({curso}) — {data['examen']} {data['periodo']}")
    print("═" * 68)
    correctos = 0
    for r in resultados:
        print(f"\n── Problema {r['id']} ──\n📌 {r['enunciado']}")
        print(tutor.formatear(r["respuesta"], r["pasos"]))
        # auto-verificación contra la respuesta esperada (si existe)
        prob = next((p for p in data["problemas"] if p.get("id") == r["id"]), {})
        esperada = prob.get("respuesta_esperada")
        if esperada is not None and r["respuesta"] is not None:
            ok = sp.simplify(r["respuesta"] - solvers.S(esperada)) == 0
            correctos += int(ok)
            print(f"  🔎 Verificación: {'✅ coincide' if ok else '❌ difiere'} "
                  f"(esperado {esperada})")
    print("\n" + "═" * 68)
    print(f"  Resueltos {len(resultados)} | verificados OK: {correctos}")
    print("═" * 68)


if __name__ == "__main__":
    main(sys.argv[1:])
